package q1;

import java.util.Scanner;

/**
 * <p>
 * Provides methods to calculate and print the perimeter and area of a triangle
 * defined by three side lengths given by the user.
 * </p>
 * <p>
 * Side lengths will be given in centimeters.
 * </p>
 * <p>
 * The perimeter and area are printed to three decimal places.
 * </p>
 *
 * @author Student Doe
 * @version 1.0
 */
public class TriangleArea {

    /** Scanner for user input. */
    private static Scanner scan;

    /**
     * <p>
     * This is the main method (entry point) that gets called by the JVM.
     * </p>
     *
     * @param args
     *            command line arguments.
     */
    public static void main(String[] args) {

        scan = new Scanner(System.in);

        displayIntro();

        Triangle triangle = new Triangle(readValidSideLength("1"),
                readValidSideLength("2"), readValidSideLength("3"));

        triangle.displayDetails();

        System.out.println("Question one was called and ran sucessfully.");

    }

    /** Displays the introductory message to the user. */
    private static void displayIntro() {

        System.out.println("Welcome to TriangleArea.");
        System.out.println();
        System.out.println(
                "After entering three side lengths of a triangle (in cm),");
        System.out.println(
                "the perimeter and area of the triangle will be shown.");
        System.out.println();

    }

    /**
     * Asks the user to enter valid side lengths (a number greater than 0) until
     * a valid value has been entered.
     * 
     * @param side
     *            The side to be given a length.
     * 
     * @return A valid side length.
     */
    private static double readValidSideLength(String side) {

        double length = -1.0;

        while (length <= 0) {

            System.out.println("Enter a length for side " + side + ": ");

            if (scan.hasNextDouble()) {

                // store the token
                length = scan.nextDouble();

                if (length <= 0) {

                    System.out.println(length + " is not a valid length.");

                }

            } else {

                // discard the token
                System.out.println(scan.next() + " is not a valid length.");

            }

            System.out.println();

        }

        System.out.println("Side " + side + " length: " + length + " cm");
        System.out.println();

        return length;

    }

};
