package q1;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * <p>
 * Defines the type Triangle.
 * </p>
 * 
 * @author Student Doe
 * @version 1.0
 */
public class Triangle {

    /** The length in centimeters of the first side of the triangle. */
    private double side1;

    /** The length in centimeters of the second side of the triangle. */
    private double side2;

    /** The length in centimeters of the third side of the triangle. */
    private double side3;

    /**
     * Constructor for the type Triangle.
     *
     * @param side1
     *            The length in centimeters of the first side of the triangle.
     * @param side2
     *            The length in centimeters of the second side of the triangle.
     * @param side3
     *            The length in centimeters of the third side of the triangle.
     */
    public Triangle(double side1, double side2, double side3) {

        this.side1 = side1;
        this.side2 = side2;

        this.side3 = checkSide3Length(side1, side2, side3);

    }

    /**
     * <p>
     * Checks whether the third side is valid given the lengths of the first two
     * sides.
     * </p>
     * <p>
     * The sum of the lengths of the smallest two sides of a triangle must be
     * greater than the length of the largest side.
     * </p>
     * 
     * @param side1
     *            The length of the first side of the triangle.
     * @param side2
     *            The length of the second side of the triangle.
     * @param side3
     *            The length of the third side of the triangle.
     *
     * @return A valid length for the third side of the triangle.
     */
    private static double checkSide3Length(double side1, double side2,
            double side3) {

        Scanner scan = new Scanner(System.in);

        while (side3 <= Math.abs(side2 - side1) || side3 >= (side2 + side1)) {

            System.out.println(
                    "The side lengths given do not create a valid triangle.");
            System.out.println();
            System.out.println("The length for side 3 must be larger than "
                    + Math.abs(side2 - side1) + " and smaller than "
                    + (side2 + side1) + ".");
            System.out.println("Please enter a value within this range: ");

            if (scan.hasNextDouble()) {

                side3 = scan.nextDouble();

            } else {

                System.out.println(scan.next() + " is not a valid length.");

            }

        }

        scan.close();

        return side3;

    }

    /**
     * Returns the length of side one.
     * 
     * @return The length of side one.
     */
    public double getSide1() {

        return side1;

    }

    /**
     * Returns the length of side two.
     * 
     * @return The length of side two.
     */
    public double getSide2() {

        return side2;

    }

    /**
     * Returns the length of side three.
     * 
     * @return The length of side three.
     */
    public double getSide3() {

        return side3;

    }

    /**
     * Calculates the perimeter of the triangle.
     * 
     * @return The perimeter of the triangle.
     */
    public double perimeter() {

        return side1 + side2 + side3;

    }

    /**
     * Calculates the area of the triangle.
     * 
     * @return The area of the triangle.
     */
    public double area() {

        double semiPerimeter = perimeter() / 2;

        return Math.sqrt(semiPerimeter * (semiPerimeter - side1)
                * (semiPerimeter - side2) * (semiPerimeter - side3));

    }

    /** Displays the perimeter and area of the triangle to the user. */
    public void displayDetails() {

        DecimalFormat fmt = new DecimalFormat("0.000");

        System.out.println("Your triangle has sides:");
        System.out.println("Side 1: " + side1 + " cm");
        System.out.println("Side 2: " + side2 + " cm");
        System.out.println("Side 3: " + side3 + " cm");
        System.out.println();
        System.out.println("The perimeter of your triangle is: "
                + fmt.format(perimeter()) + " cm");
        System.out.println("The area of your triangle is: " + fmt.format(area())
                + " cm squared");
        System.out.println();

    }

}
