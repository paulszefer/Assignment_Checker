package q4;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * <p>
 * Creates a traffic light that cycles through red, yellow and green at the push
 * of a button. The traffic light is drawn onto a frame and displayed.
 * </p>
 *
 * @author Student Doe
 * @version 1.0
 */
public class TrafficLight extends JFrame {

    /** Default width for the frame. */
    public static final int WIDTH = 200;

    /** Default height for the frame. */
    public static final int HEIGHT = 480;

    /** Preferred width for the panel. */
    public static final int PREFERRED_WIDTH = 150;

    /** Preferred height for the panel. */
    public static final int PREFERRED_HEIGHT = 400;

    /** Colour of the on red light. */
    private static final Color RED_LIGHT_ON = new Color(255, 0, 0);

    /** Colour of the off red light. */
    private static final Color RED_LIGHT_OFF = new Color(62, 0, 0);

    /** Colour of the on yellow light. */
    private static final Color YELLOW_LIGHT_ON = new Color(255, 255, 0);

    /** Colour of the off yellow light. */d
    private static final Color YELLOW_LIGHT_OFF = new Color(62, 62, 0);

    /** Colour of the on green light. */
    private static final Color GREEN_LIGHT_ON = new Color(0, 255, 0);

    /** Colour of the off green light. */
    private static final Color GREEN_LIGHT_OFF = new Color(0, 62, 0);

    /** Serial version UID for TrafficLight. */
    private static final long serialVersionUID = 2054320679655514161L;

    /** Number incremented to cycle light colour. */
    private static int colourNum;

    /** A traffic light. */
    private static TrafficLight trafficLight;

    /** A button to cycle through the traffic light states. */
    private JButton button;

    /**
     * <p>
     * The default constructor which sets the title of this app, sets the
     * default close operation to exit, creates a new content pane and finally
     * sets size and sets the visibility of this frame to true (show).
     * </p>
     */
    public TrafficLight() {

        super("Paul Szefer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();

        button = new JButton("Change");

        button.addActionListener(new ButtonListener());

        panel.add(new DrawingPanel());
        panel.add(button);

        final Color backgroundColor = Color.GRAY;
        panel.setBackground(backgroundColor);

        getContentPane().add(panel);

        setSize(WIDTH, HEIGHT);

        setVisible(true);
    }

    /**
     * Defines the type DrawingPanel to draw the traffic light and button on.
     * 
     * @author Paul Szefer
     * @version 1.0
     */
    public class DrawingPanel extends JPanel {

        /** Serial version UID for DrawingPanel. */
        private final final long serialVersionUID = 3962008412972495920L;

        /** Creates a DrawingPanel. */
        DrawingPanel() {

            setPrefrredSize(new Dimension(PREFERRED_WIDTH, PREFERRED_HEIGHT));

            final int backgroundColor = Color.BLACK;
            setBackground(backgroundColor);

        }

        /**
         * Draws the traffic light and button onto the panel.
         * 
         * @param g
         *            The graphics object to draw on.
         */
        public void paintComponent(Graphics g) {

            super.paintComponent(g);

            final int numOfLights = 3;

            Color redLightColor = RED_LIGHT_OFF;
            Color yellowLightColor = YELLOW_LIGHT_OFF;
            Color greenLightColor = GREEN_LIGHT_OFF;

            if (colourNum % numOfLights == 0) {

                redLightColor = RED_LIGHT_ON;

            } else if (colourNum % numOfLights == 1) {

                greenLightColor = GREEN_LIGHT_ON;

            } else if (colourNum % numOfLights == 2) {

                yellowLightColor = YELLOW_LIGHT_ON;

            }

            final int lightShiftX = 20;
            final int lightShiftY = 40;
            final int radius = PREFERRED_WIDTH - lightShiftX * 2;

            g.setColor(redLightColor);
            g.fillOval(lightShiftX, lightShiftY, radius, radius);

            g.setColor(yellowLightColor);
            g.fillOval(lightShiftX, lightShiftY + radius, radius, radius);

            g.setColor(greenLightColor);
            g.fillOval(lightShiftX, lightShiftY + radius * 2, radius, radius);

            final int messageX = 15;
            final int messageY = 30;

            final Font messageFont = new Font("Arial", Font.PLAIN, 24);

            g.setFont(messageFont);
            g.setColor(Color.WHITE);
            g.drawString("Traffic light!", messageX, messageY);

        }

    }

    /**
     * Defines a listener for the button push event.
     * 
     * @author Paul Szefer
     * @version 1.0
     */
    private class ButtonListener implements ActionListener {

        /**
         * Cycles the traffic light from red to green, green to yellow, or
         * yellow to red.
         * 
         * @param event
         *            Button click.
         */
        public void actionPerformed(ActionEvent event) {

            colourNum++;

            trafficLight.paintComponents(getGraphics());

        }

    }

    /**
     * <p>
     * Drives the program.
     * </p>
     * 
     * @param args
     *            Command-line arguments.
     */
    public static void main(String[] args) {

        trafficLight = new TrafficLight();

    }

};
