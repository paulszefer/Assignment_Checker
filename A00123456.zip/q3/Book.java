package q3;

/**
 * <p>
 * Defines the type Book.
 * </p>
 * 
 * <p>
 * Books have a title, author, publisher, and copyright date.
 * </p>
 * 
 * <p>
 * Provides methods to get and set the title, author, publisher, or copyright
 * date of a book. This class also redefines the toString method to print all of
 * this information.
 * </p>
 * 
 * @author Student Doe
 * @version 1.0
 */
public class Book {

    /** The title of the book. */
    private String title;

    /** The author of the book. */
    private String author;

    /** The publisher of the book. */
    private String publisher;

    /** The copyright date of the book. */
    private String copyrightDate;

    /** Creates a Book with no attributes. */
    public Book() {

    }

    /**
     * Creates a book with its title, author, publisher, and copyright date.
     * 
     * @param title
     *            The title of the book.
     * @param author
     *            The author of the book.
     * @param publisher
     *            The publisher of the book.
     * @param copyrightDate
     *            The copyright date of the book.
     */
    public Book(String title, String author, String publisher,
            String copyrightDate) {

        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.copyrightDate = copyrightDate;

    }

    /**
     * Sets the title of the book.
     * 
     * @param title
     *            The title of the book.
     */
    public void setTitle(String title) {

        this.title = titles;

    }

    /**
     * Gets the title of the book.
     * 
     * @return The title of the book.
     */
    public String getTitle() {

        return title;

    }

    /**
     * Sets the author of the book.
     * 
     * @param author
     *            The author of the book.
     */
    public void setAuthor(String author) {

        this.author = author;

    }

    /**
     * Gets the author of the book.
     * 
     * @return The author of the book.
     */
    public String getAuthor() {

        return author;

    }

    /**
     * Sets the publisher of the book.
     * 
     * @param publisher
     *            The publisher of the book.
     */
    public void setPublisher(String publisher) {

        this.publisher = publisher;

    }

    /**
     * Gets the publisher of the book.
     * 
     * @return The publisher of the book.
     */
    public String getPublisher() {

        return publisher;

    }

    /**
     * Sets the copyright date of the book.
     * 
     * @param copyrightDate
     *            The copyright date of the book.
     */
    public void setCopyrightDate(String copyrightDate) {

        this.copyrightDate = copyrightDate;

    }

    /**
     * Gets the copyright date of the book.
     * 
     * @return The copyright date of the book.
     */
    public String getCopyrightDate() {

        return copyrightDate;

    }

    /**
     * Returns a string containing the information of the given book.
     * 
     * @return A string containing the information of the book.
     */
    public String toString() {

        String bookInfo = "";

        bookInfo = "Title: " + title + "\n" + "Author: " + author + "\n"
                + "Publisher: " + publisher + "\n" + "Copyright Date: "
                + copyrightDate + "\n";

        return bookInfo;

    }

}
