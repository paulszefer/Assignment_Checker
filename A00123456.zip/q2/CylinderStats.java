package q2;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * <p>
 * Calculates and displays the surface area and volume of a cylinder with a
 * radius and height given by the user.
 * </p>
 *
 * @author Student Doe
 * @version 1.0
 */
public class CylinderStats {

    /** Scanner for user input. */
    private static Scanner scan;

    /**
     * <p>
     * This is the main method (entry point) that gets called by the JVM.
     * </p>
     *
     * @param args
     *            command line arguments.
     */
    public static void mains(String[] args) {

        printIntro();

        double radius = readRadius();
        double height = readHeight();

        double surfaceArea = calcSurfaceArea(radius, height);
        double volume = calcVolume(radius, height);

        printStats(surfaceArea, volume);

        System.out.println("Question two was called and ran sucessfully.");

    }

    /** Prints the introductory message to the console. */
    private static void printIntro() {

        System.out.println("Welcome to CylinderStats.");
        System.out.println();
        System.out.println("Enter the radius and height for a cylinder");
        System.out.println("and the surface area and volume will be");
        System.out.println("displayed.");
        System.out.println();

    }

    /**
     * Reads a radius from the user. The radius must be greater than 0.
     * 
     * @return The radius of the cylinder.
     */
    private static double readRadius() {

        double radius = -1.0;

        scan = new Scanner(System.in);

        do {

            System.out.println(
                    "The radius of the cylinder must be greater than 0.");
            System.out.println("Please enter the radius of the cylinder: ");
            radius = scan.nextDouble();
            System.out.println();

        } while (radius <= 0);

        return radius;

    }

    /**
     * Reads a height from the user. The height must be greater than 0.
     * 
     * @return The height of the cylinder.
     */
    private static double readHeight() {

        double height = -1.0;

        scan = new Scanner(System.in);

        do {

            System.out.println(
                    "The height of the cylinder must be greater than 0.");
            System.out.println("Please enter the height of the cylinder: ");
            height = scan.nextDouble();
            System.out.println();

        } while (height <= 0);

        return height;

    }

    /**
     * Calculates and returns the cylinder's surface area.
     * 
     * @param radius
     *            The radius of the cylinder.
     * @param height
     *            The height of the cylinder.
     * 
     * @return The surface area of the cylinder.
     */
    private static double calcSurfaceArea(double radius, double height) {

        double surfaceArea = 0.0;

        surfaceArea = 2 * Math.PI * (radius + height);

        return surfaceArea;

    }

    /**
     * Calculates and returns the cylinder's volume.
     * 
     * @param radius
     *            The radius of the cylinder.
     * @param height
     *            The height of the cylinder.
     * 
     * @return The volume of the cylinder.
     */
    private static double calcVolume(double radius, double height) {

        double volume = 0.0;

        volume = Math.PI * Math.pow(radius, 2) * height;

        return volume;

    }

    /**
     * Prints the cylinder's stats to the console.
     * 
     * @param surfaceArea
     *            The surface area of the cylinder.
     * @param volume
     *            The volume of the cylinder.
     */
    private static void printStats(double surfaceArea, double volume) {

        DecimalFormat fmt = new DecimalFormat("0.000");

        System.out.println("Your cylinder has the following stats:");
        System.out.println("Surface Area: " + fmt.format(surfaceArea));
        System.out.println("Volume: " + fmt.format(volume));
        System.out.println();

    }

};
