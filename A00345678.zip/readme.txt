Student Doe, A00345678, Set D, February 26, 2017

This assignment is 100% complete.


------------------------
Question one (TriangleArea) status:

Complete.

------------------------
Question two (CylinderStats) status:

Complete.

------------------------
Question three (Bookshelf) status:

Complete.

------------------------
Question four (TrafficLight) status:

Complete.
