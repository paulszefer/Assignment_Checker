package q3;

public class Bookshelf {

    /** Book with no attributes. */
    private static Book book1;

    /** Harry Potter and the Chamber of Secrets Book. */
    private static Book book2;

    /** The Return of the King Book. */
    private static Book book3;

    /** Harry Potter and the Goblet of Fire Book. */
    private static Book book4;

    /**
     * <p>
     * This is the main method (entry point) that gets called by the JVM.
     * </p>
     *
     * @param args
     *            command line arguments.
     */
    public static void main(String[] args) {

        printIntro();

        makeBooks();

        testBookMethods();

        System.out.println("Question three was called and ran sucessfully.");

    }

    /** Prints the introductory message to the console. */
    private static void printIntro() {

        System.out.println("Welcome to Bookshelf.");
        System.out.println("");
        System.out.println("This is a driver class for the Book class.");
        System.out.println("This class will create four books and then");
        System.out.println("test the methods of the book class.");
        System.out.println();

    }

    /** Makes four Books. */
    private static void makeBooks() {

        book1 = new Book();

        String book2Title = "Harry Potter and the Chamber of Secrets";
        String book2Author = "J. K. Rowling";
        String book2Publisher = "Bloomsbury";
        String book2CopyrightDate = "July 2, 1998";

        book2 = new Book(book2Title, book2Author, book2Publisher,
                book2CopyrightDate);

        String book3Title = "The Return of the King";
        String book3Author = "J. R. R. Tolkien";
        String book3Publisher = "George Allen & Unwin";
        String book3CopyrightDate = "October 20, 1955";

        book3 = new Book(book3Title, book3Author, book3Publisher,
                book3CopyrightDate);

        String book4Title = "Harry Potter and the Goblet of Fire";
        String book4Author = "J. K. Rowling";
        String book4Publisher = "Raincoast";
        String book4CopyrightDate = "July 8, 2000";

        book4 = new Book(book4Title, book4Author, book4Publisher,
                book4CopyrightDate);

    }

    /**
     * Tests the methods of the Book class. Prints the results to the console.
     */
    private static void testBookMethods() {

        System.out.println("Test book title setter:");
        System.out
                .println("Set title to: The Lion, The Witch and The Wardrobe");
        book1.setTitle("The Lion, The Witch and The Wardrobe");
        System.out.println("Test book title getter:");
        System.out.println(book1.getTitle());
        System.out.println();

        System.out.println("Test book author setter:");
        System.out.println("Set author to: C.S. Lewis");
        book1.setAuthor("C. S. Lewis");
        System.out.println("Test book author getter:");
        System.out.println(book1.getAuthor());
        System.out.println();

        System.out.println("Test book publisher setter:");
        System.out.println("Set publisher to: Geoffrey Bles");
        book1.setPublisher("Geoffrey Bles");
        System.out.println("Test book publisher getter:");
        System.out.println(book1.getPublisher());
        System.out.println();

        System.out.println("Test book copyright date setter:");
        System.out.println("Set copyright date to: October 16, 1950");
        book1.setCopyrightDate("October 16, 1950");
        System.out.println("Test book copyright date getter:");
        System.out.println(book1.getCopyrightDate());
        System.out.println();

        System.out.println("Test toString method:");
        System.out.println(book1);
        System.out.println(book2);
        System.out.println(book3);
        System.out.println(book4);

    }
};
